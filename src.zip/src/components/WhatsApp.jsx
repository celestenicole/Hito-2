function WhatsApp() {
  return <a className="btn btn-success rounded-circle btn-whatsapp" href="https://wa.me/51931091291" target="_blank" rel="noreferrer"><i className="bi bi-whatsapp"></i></a>
}
export default WhatsApp
